type PerformanceCardProps = {
  title: string;
  value: string | number;
  unit?: string;
  icon: string;
  progress?: number;
  change?: {
    value: string | number;
    type: "increase" | "decrease";
    text?: string;
  };
  iconColor?: string;
  progressColor?: string;
};

export default function PerformanceCard({
  title,
  value,
  unit,
  icon,
  progress,
  change,
  iconColor = "text-primary",
  progressColor = "bg-primary",
}: PerformanceCardProps) {
  return (
    <div className="bg-white rounded-xl shadow-sm p-4">
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-sm font-medium text-gray-500">{title}</h3>
        <i className={`material-icons ${iconColor}`}>{icon}</i>
      </div>
      <div className="flex items-end">
        <span className="text-3xl font-bold">{value}</span>
        {unit && <span className="ml-1 text-gray-500">{unit}</span>}
      </div>
      
      {progress !== undefined && (
        <div className="w-full h-2 bg-gray-100 rounded-full mt-2 overflow-hidden">
          <div 
            className={`h-full ${progressColor} rounded-full`} 
            style={{ width: `${Math.min(100, Math.max(0, progress))}%` }}
          ></div>
        </div>
      )}
      
      {change && (
        <p className="text-xs text-gray-500 mt-2">
          <span className={`inline-flex items-center ${change.type === 'increase' ? 'text-green-600' : 'text-red-600'}`}>
            <i className="material-icons text-xs mr-1">
              {change.type === 'increase' ? 'arrow_upward' : 'arrow_downward'}
            </i>
            {change.value}
          </span>
          {" "}{change.text}
        </p>
      )}
    </div>
  );
}
