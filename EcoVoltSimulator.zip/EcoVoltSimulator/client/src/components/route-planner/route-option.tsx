import { Button } from "@/components/ui/button";

type RouteOptionProps = {
  type: "eco" | "standard";
  distance: number;
  time: number;
  energySaving?: number;
  selected: boolean;
  onSelect: () => void;
};

export default function RouteOption({
  type,
  distance,
  time,
  energySaving,
  selected,
  onSelect
}: RouteOptionProps) {
  const formatDistance = (km: number) => `${km.toFixed(1)} km`;
  const formatTime = (minutes: number) => `${minutes} min`;
  
  return (
    <div 
      className={`route-option bg-white rounded-xl shadow-sm p-4 border-l-4 ${
        selected 
          ? type === 'eco' ? 'border-primary' : 'border-secondary'
          : 'border-gray-200'
      }`}
    >
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center">
          <div className={`h-8 w-8 rounded-full ${
            type === 'eco' 
              ? 'bg-primary bg-opacity-10' 
              : 'bg-gray-100'
          } flex items-center justify-center mr-2`}>
            <i className={`material-icons text-sm ${
              type === 'eco' ? 'text-primary' : 'text-gray-500'
            }`}>
              {type === 'eco' ? 'eco' : 'directions_car'}
            </i>
          </div>
          <span className="font-medium">
            {type === 'eco' ? 'Eco Path' : 'Standard Path'}
          </span>
        </div>
        <span className="text-sm text-gray-500">{formatTime(time)}</span>
      </div>
      
      <div className="flex items-center justify-between">
        <div className="flex items-center text-sm text-gray-500">
          <span>{formatDistance(distance)}</span>
          {energySaving && type === 'eco' && (
            <>
              <span className="mx-2">•</span>
              <span className="flex items-center">
                <i className="material-icons text-xs mr-1">trending_down</i>
                {energySaving}% energy saving
              </span>
            </>
          )}
          {type === 'standard' && (
            <>
              <span className="mx-2">•</span>
              <span className="flex items-center">
                <i className="material-icons text-xs mr-1">trending_up</i>
                Standard consumption
              </span>
            </>
          )}
        </div>
        <Button 
          variant="ghost" 
          className={selected 
            ? type === 'eco' ? 'text-primary' : 'text-secondary'
            : 'text-gray-500'
          }
          size="sm"
          onClick={onSelect}
        >
          {selected ? 'Selected' : 'Select'}
        </Button>
      </div>
    </div>
  );
}
