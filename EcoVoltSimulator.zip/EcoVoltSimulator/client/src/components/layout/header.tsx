import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { Bell, LogOut, User } from "lucide-react";

export default function Header() {
  const { user, logoutMutation } = useAuth();
  
  // Get vehicle data
  const { data: vehicle } = useQuery({
    queryKey: ["/api/vehicle"],
    enabled: !!user,
  });
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map(part => part[0])
      .join("")
      .toUpperCase();
  };
  
  return (
    <header className="bg-white border-b border-gray-200 py-4 px-4 flex items-center justify-between">
      <div className="flex items-center">
        <div className="h-10 w-10 bg-primary rounded-full flex items-center justify-center mr-3">
          <i className="material-icons text-white text-xl">bolt</i>
        </div>
        <div>
          <h1 className="text-lg font-bold">EcoVolt</h1>
          {vehicle && (
            <p className="text-xs text-gray-500">{vehicle.model}</p>
          )}
        </div>
      </div>
      <div className="flex items-center">
        <Button variant="ghost" size="icon" className="mr-2">
          <Bell size={20} className="text-gray-500" />
        </Button>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="relative h-8 w-8 rounded-full">
              <Avatar className="h-8 w-8">
                <AvatarFallback className="bg-gray-100 text-gray-800">
                  {user ? getInitials(user.name) : "U"}
                </AvatarFallback>
              </Avatar>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-56" align="end" forceMount>
            <div className="flex flex-col space-y-1 p-2">
              <p className="text-sm font-medium leading-none">{user?.name}</p>
              <p className="text-xs leading-none text-muted-foreground">
                {user?.username}
              </p>
            </div>
            <DropdownMenuSeparator />
            <DropdownMenuItem>
              <User className="mr-2 h-4 w-4" />
              <span>Profile</span>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={handleLogout}>
              <LogOut className="mr-2 h-4 w-4" />
              <span>Log out</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
