import { useLocation } from "wouter";
import { BarChart3, Map, Shield, LayoutDashboard } from "lucide-react";

export default function Navbar() {
  const [location, navigate] = useLocation();
  
  const navItems = [
    { icon: <LayoutDashboard />, text: "Dashboard", path: "/dashboard" },
    { icon: <Map />, text: "Routes", path: "/routes" },
    { icon: <Shield />, text: "Safety", path: "/safety" },
    { icon: <BarChart3 />, text: "Analytics", path: "/analytics" },
  ];
  
  return (
    <nav className="bg-white border-t border-gray-200 py-2">
      <div className="grid grid-cols-4 gap-1">
        {navItems.map((item) => (
          <button
            key={item.path}
            className={`flex flex-col items-center py-1 ${
              location === item.path ? "text-primary" : "text-gray-500"
            }`}
            onClick={() => navigate(item.path)}
          >
            {item.icon}
            <span className="text-xs mt-1">{item.text}</span>
          </button>
        ))}
      </div>
    </nav>
  );
}
