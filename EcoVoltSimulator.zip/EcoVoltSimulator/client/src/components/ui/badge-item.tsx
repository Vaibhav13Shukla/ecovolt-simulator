import { Badge } from "@shared/schema";

type BadgeItemProps = {
  badge: Partial<Badge>;
  size?: "sm" | "md" | "lg";
};

export default function BadgeItem({ badge, size = "md" }: BadgeItemProps) {
  const getIconColor = () => {
    if (badge.achieved) return "text-accent";
    return "text-gray-500";
  };

  const getIconBgColor = () => {
    if (badge.achieved) return "bg-accent bg-opacity-10";
    return "bg-gray-100";
  };

  const getTextColor = () => {
    if (badge.achieved) return "text-gray-800";
    return "text-gray-500";
  };

  const getSizeClasses = () => {
    switch (size) {
      case "sm":
        return {
          container: "w-16",
          iconContainer: "h-10 w-10",
          icon: "text-base",
          text: "text-xs",
        };
      case "lg":
        return {
          container: "w-28",
          iconContainer: "h-20 w-20",
          icon: "text-3xl",
          text: "text-sm",
        };
      case "md":
      default:
        return {
          container: "w-24",
          iconContainer: "h-16 w-16",
          icon: "text-xl",
          text: "text-xs",
        };
    }
  };

  const sizeClasses = getSizeClasses();

  const progressText = badge.progress !== undefined && badge.target !== undefined
    ? `${badge.progress}/${badge.target}`
    : '';

  return (
    <div className={`badge-item flex-shrink-0 ${sizeClasses.container} flex flex-col items-center`}>
      <div className={`${sizeClasses.iconContainer} rounded-full ${getIconBgColor()} flex items-center justify-center mb-2`}>
        <i className={`material-icons ${getIconColor()} ${sizeClasses.icon}`}>{badge.icon || "star"}</i>
      </div>
      <span className={`${sizeClasses.text} font-medium text-center ${getTextColor()}`}>
        {badge.name || "Badge"}
      </span>
      {!badge.achieved && progressText && (
        <span className={`${sizeClasses.text} text-gray-500`}>{progressText}</span>
      )}
    </div>
  );
}
