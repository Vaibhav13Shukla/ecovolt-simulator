type EcoMeterProps = {
  value: number;
  label?: string;
};

export default function EcoMeter({ value, label = "Eco Score" }: EcoMeterProps) {
  // Ensure value is between 0 and 100
  const safeValue = Math.min(100, Math.max(0, value));
  
  // Determine color class based on the value
  const getColorClass = () => {
    if (safeValue < 30) return "text-destructive";
    if (safeValue < 60) return "text-primary";
    return "text-secondary";
  };
  
  // Set the CSS variable for the conic gradient
  const style = {
    "--eco-value": `${safeValue}%`
  } as React.CSSProperties;
  
  return (
    <div className="eco-meter animate-float" style={style}>
      <div className="eco-meter-inner">
        <span className={`text-2xl font-bold ${getColorClass()}`}>
          {Math.round(safeValue)}
        </span>
        <span className="text-xs text-gray-500 font-medium mt-1">{label}</span>
      </div>
    </div>
  );
}
