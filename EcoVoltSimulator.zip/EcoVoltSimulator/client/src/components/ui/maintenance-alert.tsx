import { useState } from "react";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";

type MaintenanceAlertProps = {
  title: string;
  description: string;
  type?: "warning" | "info" | "error";
  onDismiss?: () => void;
  onAction?: () => void;
  actionLabel?: string;
};

export default function MaintenanceAlert({
  title,
  description,
  type = "warning",
  onDismiss,
  onAction,
  actionLabel = "Schedule",
}: MaintenanceAlertProps) {
  const [visible, setVisible] = useState(true);
  
  if (!visible) return null;
  
  const handleDismiss = () => {
    setVisible(false);
    if (onDismiss) onDismiss();
  };
  
  // Get Pokémon-themed icon and color based on alert type
  const getPokemonType = () => {
    switch (type) {
      case "warning": return "electric"; // Pikachu theme
      case "error": return "fire"; // Charmander theme
      case "info": return "water"; // Squirtle theme
      default: return "electric";
    }
  };
  
  const getBgColor = () => {
    switch (type) {
      case "warning": return "bg-primary/15";
      case "error": return "bg-destructive/15";
      case "info": return "bg-accent/15";
      default: return "bg-primary/15";
    }
  };
  
  const getIconColor = () => {
    switch (type) {
      case "warning": return "text-primary";
      case "error": return "text-destructive";
      case "info": return "text-accent";
      default: return "text-primary";
    }
  };
  
  const getIcon = () => {
    switch (type) {
      case "warning": return "bolt"; // Electric Pokemon symbol
      case "error": return "local_fire_department"; // Fire Pokemon symbol
      case "info": return "water_drop"; // Water Pokemon symbol
      default: return "bolt";
    }
  };
  
  const getPokemonTheme = () => {
    const pokemonType = getPokemonType();
    switch (pokemonType) {
      case "electric":
        return "after:bg-primary/20 after:from-yellow-400/30 after:to-transparent";
      case "fire":
        return "after:bg-destructive/20 after:from-red-400/30 after:to-transparent";
      case "water":
        return "after:bg-accent/20 after:from-blue-400/30 after:to-transparent";
      default:
        return "after:bg-primary/20 after:from-yellow-400/30 after:to-transparent";
    }
  };
  
  return (
    <div className={`fixed bottom-20 left-4 right-4 card shadow-lg p-0 overflow-hidden z-50 after:content-[''] after:absolute after:inset-0 after:bg-gradient-to-r ${getPokemonTheme()}`}>
      <div className="relative z-10 p-4">
        <div className="flex items-start">
          <div className={`pokeball-button mr-4 ${type === "error" ? "bg-gradient-to-b from-destructive to-white" : 
            type === "info" ? "bg-gradient-to-b from-accent to-white" : 
            "bg-gradient-to-b from-primary to-white"}`}>
            <i className={`material-icons ${getIconColor()} text-sm absolute z-20`}>{getIcon()}</i>
          </div>
          <div className="flex-1">
            <div className="flex justify-between items-start mb-2">
              <h3 className="font-bold text-foreground">{title}</h3>
              <button onClick={handleDismiss} className="text-muted-foreground hover:text-foreground transition-colors">
                <X size={18} />
              </button>
            </div>
            <p className="text-sm text-muted-foreground mb-4">{description}</p>
            <div className="flex space-x-3">
              {onAction && (
                <Button 
                  variant={type === "error" ? "destructive" : type === "info" ? "secondary" : "default"}
                  size="sm"
                  onClick={onAction}
                  className="flex-1 font-medium"
                >
                  {actionLabel}
                </Button>
              )}
              <Button 
                variant="outline"
                size="sm"
                onClick={handleDismiss}
                className="flex-1"
              >
                Dismiss
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
