import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { vehicleModelsData } from "@shared/schema";

type OnboardingScreenProps = {
  onComplete: (data: { vehicleType: string; vehicleModel: string }) => void;
  isVisible: boolean;
};

export default function OnboardingScreen({ onComplete, isVisible }: OnboardingScreenProps) {
  const [vehicleType, setVehicleType] = useState<string>("ev");
  const [vehicleModel, setVehicleModel] = useState<string>(vehicleModelsData.ev[0]);
  
  if (!isVisible) return null;
  
  const handleComplete = () => {
    onComplete({
      vehicleType,
      vehicleModel
    });
  };
  
  return (
    <div className="fixed inset-0 bg-white z-50 flex flex-col items-center justify-center p-6">
      <div className="w-full max-w-md">
        <div className="text-center mb-10">
          <div className="flex justify-center items-center mb-4">
            <div className="relative h-20 w-20">
              <div className="absolute inset-0 bg-primary rounded-full opacity-20 animate-ping-slow"></div>
              <div className="relative flex items-center justify-center h-20 w-20 bg-primary rounded-full">
                <i className="material-icons text-white text-3xl">bolt</i>
              </div>
            </div>
          </div>
          <h1 className="text-3xl font-bold text-gray-800 mb-2">EcoVolt Simulator</h1>
          <p className="text-gray-500">Optimize Your Ride, Sustainably!</p>
        </div>
        
        <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">Welcome to EcoVolt</h2>
          <p className="text-gray-500 mb-6">Choose your vehicle type to get started:</p>
          
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div 
              className={`border-2 ${vehicleType === 'ev' ? 'border-secondary' : 'border-gray-200'} 
                rounded-lg p-4 cursor-pointer hover:bg-gray-50 transition duration-200 
                flex flex-col items-center`}
              onClick={() => {
                setVehicleType('ev');
                setVehicleModel(vehicleModelsData.ev[0]);
              }}
            >
              <div className="h-16 w-16 bg-secondary bg-opacity-10 rounded-full flex items-center justify-center mb-2">
                <i className="material-icons text-secondary">electric_car</i>
              </div>
              <span className="font-medium">Electric Vehicle</span>
            </div>
            <div 
              className={`border-2 ${vehicleType === 'robot' ? 'border-secondary' : 'border-gray-200'} 
                rounded-lg p-4 cursor-pointer hover:bg-gray-50 transition duration-200 
                flex flex-col items-center`}
              onClick={() => {
                setVehicleType('robot');
                setVehicleModel(vehicleModelsData.robot[0]);
              }}
            >
              <div className="h-16 w-16 bg-gray-100 rounded-full flex items-center justify-center mb-2">
                <i className="material-icons text-gray-500">precision_manufacturing</i>
              </div>
              <span className="font-medium">Delivery Robot</span>
            </div>
          </div>
          
          <div className="mb-6">
            <h3 className="text-sm font-medium text-gray-500 mb-2">Select Your Model</h3>
            <Select 
              value={vehicleModel}
              onValueChange={setVehicleModel}
            >
              <SelectTrigger className="w-full p-3 border border-gray-200 rounded-lg bg-gray-50">
                <SelectValue placeholder="Select a vehicle model" />
              </SelectTrigger>
              <SelectContent>
                {vehicleType === 'ev' ? (
                  vehicleModelsData.ev.map((model) => (
                    <SelectItem key={model} value={model}>{model}</SelectItem>
                  ))
                ) : (
                  vehicleModelsData.robot.map((model) => (
                    <SelectItem key={model} value={model}>{model}</SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </div>
          
          <Button 
            className="w-full py-3 px-4 bg-primary text-white font-semibold rounded-lg hover:bg-opacity-90 transition duration-200"
            onClick={handleComplete}
          >
            Get Started
          </Button>
        </div>
      </div>
    </div>
  );
}
