// This file contains mock data to make the application work without a backend
// For GitHub Pages deployment

import { User, Vehicle, Badge, Metrics } from "@shared/schema";

export const mockUser: Omit<User, "password"> = {
  id: 1,
  username: "demo",
  name: "Demo User",
  vehicleType: "ev",
  vehicleModel: "Model X",
  ecoLevel: "intermediate"
};

export const mockVehicle: Vehicle = {
  id: 1,
  userId: 1,
  type: "ev",
  model: "Model X",
  batteryLevel: 80,
  batteryHealth: 95,
  motorHealth: 92,
  range: 300,
  lastMaintenanceAt: new Date()
};

export const mockMetrics: Metrics = {
  id: 1,
  userId: 1,
  batteryLevel: 80,
  speed: 0,
  distance: "157.3",
  batteryHealth: 95,
  motorHealth: 92,
  ecoScore: 75,
  co2Saved: "12.5",
  energySaved: "18.7",
  timestamp: new Date()
};

export const mockBadges: Badge[] = [
  {
    id: 1,
    userId: 1,
    name: "Eco Master",
    description: "Save 10kg of CO2",
    icon: "eco",
    progress: 5,
    target: 10,
    achieved: false,
    achievedAt: null
  },
  {
    id: 2,
    userId: 1,
    name: "Energy Saver",
    description: "Save 20kWh of energy",
    icon: "bolt",
    progress: 18,
    target: 20,
    achieved: false,
    achievedAt: null
  },
  {
    id: 3,
    userId: 1,
    name: "Route Genius",
    description: "Complete 5 eco-friendly trips",
    icon: "map",
    progress: 2,
    target: 5,
    achieved: false,
    achievedAt: null
  },
  {
    id: 4,
    userId: 1,
    name: "Early Bird",
    description: "Use the app 7 days in a row",
    icon: "timer",
    progress: 4,
    target: 7,
    achieved: false,
    achievedAt: null
  }
];

export const mockStats = {
  totalTrips: 12,
  ecoTrips: 7,
  badges: mockBadges
};

// Function to simulate API delays for a more realistic experience
export function mockFetch<T>(data: T, delay = 300): Promise<T> {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(data);
    }, delay);
  });
}