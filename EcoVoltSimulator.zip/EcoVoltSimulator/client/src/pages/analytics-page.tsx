import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import Navbar from "@/components/layout/navbar";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";

type TimeRange = "week" | "month" | "year";

export default function AnalyticsPage() {
  const { user } = useAuth();
  const [timeRange, setTimeRange] = useState<TimeRange>("week");
  
  // Get metrics data
  const { data: metrics, isLoading: loadingMetrics } = useQuery({
    queryKey: ["/api/metrics/latest"],
    enabled: !!user,
  });
  
  // Get stats data
  const { data: stats, isLoading: loadingStats } = useQuery({
    queryKey: ["/api/stats"],
    enabled: !!user,
  });
  
  // Get vehicle data
  const { data: vehicle, isLoading: loadingVehicle } = useQuery({
    queryKey: ["/api/vehicle"],
    enabled: !!user,
  });
  
  // Create weekday data
  const weekDays = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  // This would come from the API in a real app
  const mockWeekData = [
    { day: "Mon", value: 60 },
    { day: "Tue", value: 45 },
    { day: "Wed", value: 80 },
    { day: "Thu", value: 30 },
    { day: "Fri", value: 55 },
    { day: "Sat", value: 20 },
    { day: "Sun", value: 40 }
  ];
  
  const isLoading = loadingMetrics || loadingStats || loadingVehicle;
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  return (
    <div className="h-screen flex flex-col overflow-hidden">
      <Header />
      
      <main className="flex-1 overflow-y-auto">
        <div className="p-4">
          <h2 className="text-xl font-bold mb-4">Performance Analytics</h2>
          
          <div className="flex items-center justify-between mb-4">
            <div className="flex space-x-2">
              <Button
                variant={timeRange === "week" ? "default" : "outline"}
                className={timeRange === "week" ? "bg-primary text-white" : "text-gray-500 bg-gray-100"}
                size="sm"
                onClick={() => setTimeRange("week")}
              >
                Week
              </Button>
              <Button
                variant={timeRange === "month" ? "default" : "outline"}
                className={timeRange === "month" ? "bg-primary text-white" : "text-gray-500 bg-gray-100"}
                size="sm"
                onClick={() => setTimeRange("month")}
              >
                Month
              </Button>
              <Button
                variant={timeRange === "year" ? "default" : "outline"}
                className={timeRange === "year" ? "bg-primary text-white" : "text-gray-500 bg-gray-100"}
                size="sm"
                onClick={() => setTimeRange("year")}
              >
                Year
              </Button>
            </div>
            <Button variant="ghost" size="sm" className="text-secondary">
              Export
            </Button>
          </div>
          
          <div className="bg-white rounded-xl shadow-sm p-4 mb-4">
            <h3 className="text-sm font-medium text-gray-500 mb-4">Energy Consumption</h3>
            <div className="h-40 flex items-end justify-between">
              {mockWeekData.map((day, index) => (
                <div key={index} className="flex flex-col items-center">
                  <div 
                    className={`w-8 ${index === 2 ? 'bg-primary' : 'bg-primary bg-opacity-20'} rounded-t-sm`} 
                    style={{ height: `${day.value}%` }}
                  ></div>
                  <span className="text-xs text-gray-500 mt-2">{day.day}</span>
                </div>
              ))}
            </div>
            <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-100">
              <div>
                <span className="text-gray-500 text-sm">Weekly Average</span>
                <div className="font-medium">14.2 kWh</div>
              </div>
              <div className="text-right">
                <span className="text-gray-500 text-sm">Most Efficient Day</span>
                <div className="font-medium text-green-600">Saturday</div>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div className="bg-white rounded-xl shadow-sm p-4">
              <h3 className="text-sm font-medium text-gray-500 mb-2">Total Trips</h3>
              <div className="text-2xl font-bold">{stats?.totalTrips || 0}</div>
              <div className="text-xs text-green-600 mt-1">
                <i className="material-icons text-xs align-middle">arrow_upward</i> 20% increase
              </div>
            </div>
            
            <div className="bg-white rounded-xl shadow-sm p-4">
              <h3 className="text-sm font-medium text-gray-500 mb-2">Eco Routes</h3>
              <div className="text-2xl font-bold">{stats?.ecoTrips || 0}</div>
              <div className="text-xs text-gray-500 mt-1">
                {stats?.totalTrips ? Math.round((stats.ecoTrips / stats.totalTrips) * 100) : 0}% of total trips
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-xl shadow-sm p-4">
            <h3 className="text-sm font-medium text-gray-500 mb-4">Maintenance Prediction</h3>
            
            <div className="flex items-center mb-6">
              <div className="h-12 w-12 bg-gray-100 rounded-full flex items-center justify-center mr-4">
                <i className="material-icons text-gray-500">battery_alert</i>
              </div>
              <div className="flex-1">
                <h4 className="font-medium">Battery Health</h4>
                <div className="w-full h-1.5 bg-gray-100 rounded-full overflow-hidden mt-1">
                  <div 
                    className="h-full bg-green-600 rounded-full" 
                    style={{ width: `${vehicle?.batteryHealth || 0}%` }}
                  ></div>
                </div>
                <div className="flex justify-between text-xs mt-1">
                  <span className="text-green-600 font-medium">{vehicle?.batteryHealth || 0}% health</span>
                  <span className="text-gray-500">Next check: 3 months</span>
                </div>
              </div>
            </div>
            
            <div className="flex items-center">
              <div className="h-12 w-12 bg-amber-100 rounded-full flex items-center justify-center mr-4">
                <i className="material-icons text-amber-500">engineering</i>
              </div>
              <div className="flex-1">
                <h4 className="font-medium">Motor Wear</h4>
                <div className="w-full h-1.5 bg-gray-100 rounded-full overflow-hidden mt-1">
                  <div 
                    className="h-full bg-amber-500 rounded-full" 
                    style={{ width: `${vehicle?.motorHealth || 0}%` }}
                  ></div>
                </div>
                <div className="flex justify-between text-xs mt-1">
                  <span className="text-amber-500 font-medium">{vehicle?.motorHealth || 0}% health</span>
                  <span className="text-gray-500">
                    {(vehicle?.motorHealth || 0) < 80 ? "Service recommended" : "Good condition"}
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Navbar />
    </div>
  );
}
