import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import Header from "@/components/layout/header";
import Navbar from "@/components/layout/navbar";
import { Metrics, Vehicle, Badge } from "@shared/schema";
import PerformanceCard from "@/components/dashboard/performance-card";
import EcoMeter from "@/components/ui/eco-meter";
import BadgeItem from "@/components/ui/badge-item";
import MaintenanceAlert from "@/components/ui/maintenance-alert";
import OnboardingScreen from "@/components/onboarding/onboarding-screen";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Loader2 } from "lucide-react";

export default function DashboardPage() {
  const { user } = useAuth();
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [showMaintenanceAlert, setShowMaintenanceAlert] = useState(false);
  
  useEffect(() => {
    const hasOnboarded = localStorage.getItem('hasOnboarded');
    if (!hasOnboarded) {
      setShowOnboarding(true);
    }
    
    // Show maintenance alert after a delay
    const timer = setTimeout(() => {
      if (metrics && metrics.motorHealth < 80) {
        setShowMaintenanceAlert(true);
      }
    }, 5000);
    
    return () => clearTimeout(timer);
  }, []);
  
  const handleOnboardingComplete = (data: { vehicleType: string; vehicleModel: string }) => {
    localStorage.setItem('hasOnboarded', 'true');
    setShowOnboarding(false);
  };
  
  // Fetch vehicle and metrics data
  const { data: vehicle = {}, isLoading: loadingVehicle } = useQuery<Vehicle>({
    queryKey: ["/api/vehicle"],
    enabled: !!user,
  });
  
  const { data: metrics = {}, isLoading: loadingMetrics } = useQuery<Metrics>({
    queryKey: ["/api/metrics/latest"],
    enabled: !!user,
  });
  
  const { data: badges = [], isLoading: loadingBadges } = useQuery<Badge[]>({
    queryKey: ["/api/badges"],
    enabled: !!user,
  });
  
  const { data: stats = {} } = useQuery({
    queryKey: ["/api/stats"],
    enabled: !!user,
  });
  
  const maintainMetrics = useQuery({
    queryKey: ["/api/metrics/latest"],
    enabled: !!user,
  });
  
  const isLoading = loadingVehicle || loadingMetrics || loadingBadges;
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  return (
    <div className="h-screen flex flex-col overflow-hidden">
      <OnboardingScreen 
        isVisible={showOnboarding} 
        onComplete={handleOnboardingComplete} 
      />
      
      <Header />
      
      <main className="flex-1 overflow-y-auto bg-gradient-to-b from-background to-background/80">
        <div className="pokemon-header py-4 px-6 shadow-md">
          <h1 className="text-2xl font-bold">EcoVolt Trainer Dashboard</h1>
          <p className="text-sm opacity-80">Welcome back, {user?.name || "Trainer"}!</p>
        </div>
        
        <div id="dashboard-view" className="p-6 max-w-6xl mx-auto">
          <div className="mb-8">
            <div className="flex items-center mb-4">
              <div className="w-2 h-8 bg-primary rounded-full mr-3"></div>
              <h2 className="text-xl font-bold">Performance Stats</h2>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Battery Card - Electric Type (Pikachu) Themed */}
              <div className="card hover:border-primary/50 p-4 group">
                <PerformanceCard
                  title="Battery Energy"
                  value={metrics?.batteryLevel || 0}
                  unit="%"
                  icon="bolt"
                  progress={metrics?.batteryLevel || 0}
                  change={{
                    value: "5%",
                    type: "increase",
                    text: "since last charge"
                  }}
                  iconColor="text-primary"
                  progressColor="bg-primary"
                />
                <div className="w-full h-1 mt-3 bg-muted overflow-hidden rounded-full">
                  <div className="h-full bg-primary animate-pulse-pokeball" 
                    style={{width: `${metrics?.batteryLevel || 0}%`}}></div>
                </div>
              </div>
              
              {/* Range Card - Grass Type (Bulbasaur) Themed */}
              <div className="card hover:border-secondary/50 p-4 group">
                <PerformanceCard
                  title="Travel Range"
                  value={vehicle?.range || 0}
                  unit="km"
                  icon="route"
                  progress={62}
                  iconColor="text-secondary"
                  progressColor="bg-secondary"
                />
                <div className="w-full h-1 mt-3 bg-muted overflow-hidden rounded-full">
                  <div className="h-full bg-secondary" style={{width: "62%"}}></div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mb-8">
            <div className="flex items-center mb-4">
              <div className="w-2 h-8 bg-accent rounded-full mr-3"></div>
              <h2 className="text-xl font-bold">Eco Power Level</h2>
              <button className="ml-auto text-accent text-sm font-medium hover:underline flex items-center">
                <span>See Details</span>
                <span className="material-icons ml-1 text-sm">chevron_right</span>
              </button>
            </div>
            
            <div className="card p-6 flex flex-col md:flex-row items-center gap-6">
              <div className="relative">
                <EcoMeter value={metrics?.ecoScore || 0} label="Eco Power" />
              </div>
              
              <div className="flex-1 w-full">
                <div className="mb-5">
                  <div className="flex items-center justify-between text-sm mb-2">
                    <div className="flex items-center">
                      <span className="material-icons text-destructive mr-2">spa</span>
                      <span className="font-medium">CO₂ Saved</span>
                    </div>
                    <span className="font-bold text-destructive">{metrics ? parseFloat(metrics.co2Saved).toFixed(1) : 0} kg</span>
                  </div>
                  <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-destructive rounded-full" 
                      style={{ width: `${Math.min(100, (metrics?.co2Saved || 0) * 10)}%` }}
                    ></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex items-center justify-between text-sm mb-2">
                    <div className="flex items-center">
                      <span className="material-icons text-secondary mr-2">bolt</span>
                      <span className="font-medium">Energy Saved</span>
                    </div>
                    <span className="font-bold text-secondary">{metrics ? parseFloat(metrics.energySaved).toFixed(1) : 0} kWh</span>
                  </div>
                  <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-secondary rounded-full" 
                      style={{ width: `${Math.min(100, (metrics?.energySaved || 0) * 5)}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mb-8">
            <div className="flex items-center mb-4">
              <div className="w-2 h-8 bg-primary rounded-full mr-3"></div>
              <h2 className="text-xl font-bold">Trainer Badges</h2>
              <button className="ml-auto text-primary text-sm font-medium hover:underline flex items-center">
                <span>View All</span>
                <span className="material-icons ml-1 text-sm">chevron_right</span>
              </button>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {badges && badges.map((badge) => (
                <div key={badge.id} className="card p-4 flex flex-col items-center text-center">
                  <BadgeItem badge={badge} />
                  <p className="mt-2 font-semibold text-sm">{badge.name}</p>
                  <p className="text-xs text-muted-foreground mt-1">{badge.description}</p>
                  <div className="w-full h-1.5 bg-muted mt-2 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-accent rounded-full transition-all duration-1000" 
                      style={{ width: `${Math.min(100, (badge.progress / badge.target) * 100)}%` }}
                    ></div>
                  </div>
                  <p className="text-xs mt-1">{badge.progress}/{badge.target}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
      
      <Navbar />
      
      {showMaintenanceAlert && (
        <MaintenanceAlert
          title="Maintenance Alert"
          description="Motor efficiency reduced to 75%. Service recommended."
          onDismiss={() => setShowMaintenanceAlert(false)}
          onAction={() => console.log("Schedule maintenance")}
        />
      )}
    </div>
  );
}
