import { useEffect } from "react";
import { useLocation } from "wouter";
import { Redirect } from "wouter";

export default function HomePage() {
  const [, navigate] = useLocation();

  useEffect(() => {
    // Redirect to dashboard page as it's the default view
    navigate("/dashboard");
  }, [navigate]);

  return <Redirect to="/dashboard" />;
}
