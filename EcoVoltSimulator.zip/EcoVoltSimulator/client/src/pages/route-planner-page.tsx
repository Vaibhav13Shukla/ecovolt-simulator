import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import Header from "@/components/layout/header";
import Navbar from "@/components/layout/navbar";
import RouteOption from "@/components/route-planner/route-option";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Navigation } from "lucide-react";

export default function RoutePlannerPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [startPoint, setStartPoint] = useState("Home");
  const [endPoint, setEndPoint] = useState("Office");
  const [selectedRouteType, setSelectedRouteType] = useState<"eco" | "standard">("eco");
  const [isRoutePlanned, setIsRoutePlanned] = useState(false);
  
  // Route data (would be fetched from API in a real app)
  const [ecoRoute] = useState({
    distance: 12.4,
    time: 29,
    energySaving: 15
  });
  
  const [standardRoute] = useState({
    distance: 10.8,
    time: 24
  });
  
  // Simulated route mutation
  const simulateRouteMutation = useMutation({
    mutationFn: async (data: { startPoint: string; endPoint: string; routeType: "eco" | "standard" }) => {
      const res = await apiRequest("POST", "/api/simulate/route", data);
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/metrics/latest"] });
      queryClient.invalidateQueries({ queryKey: ["/api/vehicle"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Trip Completed",
        description: `Successfully completed a trip from ${startPoint} to ${endPoint}`,
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to simulate route",
        variant: "destructive",
      });
    },
  });
  
  const handlePlanRoute = () => {
    // Validate inputs
    if (!startPoint.trim() || !endPoint.trim()) {
      toast({
        title: "Invalid Input",
        description: "Please enter both start point and destination",
        variant: "destructive",
      });
      return;
    }
    
    setIsRoutePlanned(true);
  };
  
  const handleStartTrip = () => {
    simulateRouteMutation.mutate({
      startPoint,
      endPoint,
      routeType: selectedRouteType
    });
  };
  
  return (
    <div className="h-screen flex flex-col overflow-hidden">
      <Header />
      
      <main className="flex-1 overflow-y-auto">
        <div className="p-4">
          <h2 className="text-xl font-bold mb-4">Route Planner</h2>
          
          <div className="bg-white rounded-xl shadow-sm p-4 mb-4">
            <div className="flex items-center mb-4">
              <div className="h-10 w-10 rounded-full bg-primary bg-opacity-10 flex items-center justify-center">
                <i className="material-icons text-primary">location_on</i>
              </div>
              <div className="ml-3 flex-1">
                <Input 
                  type="text" 
                  placeholder="Current location" 
                  value={startPoint}
                  onChange={(e) => setStartPoint(e.target.value)}
                  className="w-full p-2 bg-gray-50 border border-gray-200 rounded-lg"
                />
              </div>
            </div>
            
            <div className="flex items-center">
              <div className="h-10 w-10 rounded-full bg-secondary bg-opacity-10 flex items-center justify-center">
                <i className="material-icons text-secondary">flag</i>
              </div>
              <div className="ml-3 flex-1">
                <Input 
                  type="text" 
                  placeholder="Destination" 
                  value={endPoint}
                  onChange={(e) => setEndPoint(e.target.value)}
                  className="w-full p-2 bg-gray-50 border border-gray-200 rounded-lg"
                />
              </div>
            </div>
            
            <Button 
              className="w-full mt-4 bg-secondary hover:bg-secondary/90"
              onClick={handlePlanRoute}
            >
              Plan Route
            </Button>
          </div>
        </div>
        
        {isRoutePlanned && (
          <>
            <div className="relative h-64 bg-gray-200 map-container" style={{
              backgroundImage: "url('https://images.unsplash.com/photo-1569336415962-a4bd9f69cd83?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80')"
            }}>
              <div className="absolute inset-0 bg-black bg-opacity-10"></div>
              <div className="absolute bottom-4 right-4">
                <Button variant="secondary" size="icon" className="h-10 w-10 rounded-full bg-white shadow-lg">
                  <Navigation className="h-5 w-5 text-gray-500" />
                </Button>
              </div>
            </div>
            
            <div className="p-4">
              <h3 className="text-lg font-semibold mb-3">Route Options</h3>
              
              <div className="space-y-4 mb-4">
                <RouteOption
                  type="eco"
                  distance={ecoRoute.distance}
                  time={ecoRoute.time}
                  energySaving={ecoRoute.energySaving}
                  selected={selectedRouteType === "eco"}
                  onSelect={() => setSelectedRouteType("eco")}
                />
                
                <RouteOption
                  type="standard"
                  distance={standardRoute.distance}
                  time={standardRoute.time}
                  selected={selectedRouteType === "standard"}
                  onSelect={() => setSelectedRouteType("standard")}
                />
              </div>
              
              <Button 
                className="w-full bg-primary hover:bg-primary/90"
                onClick={handleStartTrip}
                disabled={simulateRouteMutation.isPending}
              >
                {simulateRouteMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Simulating trip...
                  </>
                ) : "Start Trip"}
              </Button>
            </div>
          </>
        )}
      </main>
      
      <Navbar />
    </div>
  );
}
