import { useState } from "react";
import Header from "@/components/layout/header";
import Navbar from "@/components/layout/navbar";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { useToast } from "@/hooks/use-toast";

export default function SafetyPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [arEnabled, setArEnabled] = useState(true);
  const [geoFencingEnabled, setGeoFencingEnabled] = useState(false);
  const [boundaryRadius, setBoundaryRadius] = useState(5);
  const [roadConditionAlerts, setRoadConditionAlerts] = useState(true);
  const [weatherAlerts, setWeatherAlerts] = useState(true);
  const [trafficAlerts, setTrafficAlerts] = useState(true);
  
  const handleLaunchARView = () => {
    toast({
      title: "AR View",
      description: "AR View would launch in a real app. This is a simulated feature.",
    });
  };
  
  const handleEditBoundaries = () => {
    toast({
      title: "Geo-Fencing",
      description: "Boundary editing would be available in a real app. This is a simulated feature.",
    });
  };
  
  return (
    <div className="h-screen flex flex-col overflow-hidden">
      <Header />
      
      <main className="flex-1 overflow-y-auto">
        <div className="p-4">
          <h2 className="text-xl font-bold mb-4">Safety Features</h2>
          
          <div className="bg-white rounded-xl shadow-sm p-4 mb-4">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center">
                <div className="h-10 w-10 rounded-full bg-primary bg-opacity-10 flex items-center justify-center mr-3">
                  <i className="material-icons text-primary">360</i>
                </div>
                <div>
                  <h3 className="font-medium">AR Safety Overlay</h3>
                  <p className="text-sm text-gray-500">View hazards in real-time</p>
                </div>
              </div>
              <Switch
                checked={arEnabled}
                onCheckedChange={setArEnabled}
              />
            </div>
            
            <Button 
              className="w-full py-2 bg-secondary text-white font-medium rounded-lg"
              onClick={handleLaunchARView}
              disabled={!arEnabled}
            >
              Launch AR View
            </Button>
          </div>
          
          <div className="bg-white rounded-xl shadow-sm p-4 mb-4">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center">
                <div className="h-10 w-10 rounded-full bg-secondary bg-opacity-10 flex items-center justify-center mr-3">
                  <i className="material-icons text-secondary">fence</i>
                </div>
                <div>
                  <h3 className="font-medium">Geo-Fencing</h3>
                  <p className="text-sm text-gray-500">Set boundaries for your vehicle</p>
                </div>
              </div>
              <Switch
                checked={geoFencingEnabled}
                onCheckedChange={setGeoFencingEnabled}
              />
            </div>
            
            <div className={geoFencingEnabled ? "" : "opacity-50 pointer-events-none"}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-500">Boundary Radius</span>
                <span className="text-sm font-medium">{boundaryRadius} km</span>
              </div>
              <Slider
                value={[boundaryRadius]}
                min={1}
                max={10}
                step={1}
                onValueChange={(value) => setBoundaryRadius(value[0])}
                disabled={!geoFencingEnabled}
                className="mb-4"
              />
              <Button 
                className="w-full py-2 bg-gray-100 text-gray-500 font-medium rounded-lg"
                onClick={handleEditBoundaries}
                disabled={!geoFencingEnabled}
              >
                Edit Boundaries
              </Button>
            </div>
          </div>
          
          <div className="bg-white rounded-xl shadow-sm p-4">
            <div className="flex items-center mb-4">
              <div className="h-10 w-10 rounded-full bg-amber-100 flex items-center justify-center mr-3">
                <i className="material-icons text-amber-500">warning</i>
              </div>
              <div>
                <h3 className="font-medium">Hazard Notifications</h3>
                <p className="text-sm text-gray-500">Get alerts for potential hazards</p>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm">Road Condition Alerts</span>
                <Switch
                  checked={roadConditionAlerts}
                  onCheckedChange={setRoadConditionAlerts}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm">Weather Alerts</span>
                <Switch
                  checked={weatherAlerts}
                  onCheckedChange={setWeatherAlerts}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm">Traffic Alerts</span>
                <Switch
                  checked={trafficAlerts}
                  onCheckedChange={setTrafficAlerts}
                />
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Navbar />
    </div>
  );
}
