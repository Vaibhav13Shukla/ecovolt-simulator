import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { useState, useEffect } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { insertUserSchema, loginSchema, vehicleModelsData } from "@shared/schema";
import { useLocation } from "wouter";
import { Loader2 } from "lucide-react";

const registerSchema = insertUserSchema.extend({
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

type RegisterFormData = z.infer<typeof registerSchema>;
type LoginFormData = z.infer<typeof loginSchema>;

export default function AuthPage() {
  const { user, loginMutation, registerMutation } = useAuth();
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState<string>("login");
  const [selectedVehicleType, setSelectedVehicleType] = useState<string>("ev");

  // Redirect if user is already logged in
  useEffect(() => {
    if (user) {
      navigate("/");
    }
  }, [user, navigate]);

  // Login form
  const loginForm = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  // Registration form
  const registerForm = useForm<RegisterFormData>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      password: "",
      confirmPassword: "",
      name: "",
      vehicleType: "ev",
      vehicleModel: "Tesla Model 3",
    },
  });

  const onLoginSubmit = (data: LoginFormData) => {
    loginMutation.mutate(data);
  };

  const onRegisterSubmit = (data: RegisterFormData) => {
    const { confirmPassword, ...userData } = data;
    registerMutation.mutate(userData);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col sm:flex-row">
      {/* Left side - Authentication Form */}
      <div className="w-full sm:w-1/2 flex flex-col items-center justify-center p-6">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <div className="flex justify-center items-center mb-4">
              <div className="relative h-16 w-16">
                <div className="absolute inset-0 bg-primary rounded-full opacity-20 animate-ping-slow"></div>
                <div className="relative flex items-center justify-center h-16 w-16 bg-primary rounded-full">
                  <i className="material-icons text-white text-2xl">bolt</i>
                </div>
              </div>
            </div>
            <h1 className="text-2xl font-bold text-gray-800 mb-2">EcoVolt Simulator</h1>
            <p className="text-gray-500">Optimize Your Ride, Sustainably!</p>
          </div>

          <Tabs defaultValue="login" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-2 mb-6">
              <TabsTrigger value="login">Log In</TabsTrigger>
              <TabsTrigger value="register">Register</TabsTrigger>
            </TabsList>

            <TabsContent value="login">
              <Card>
                <CardContent className="pt-6">
                  <Form {...loginForm}>
                    <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                      <FormField
                        control={loginForm.control}
                        name="username"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Username</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter your username" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={loginForm.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Password</FormLabel>
                            <FormControl>
                              <Input type="password" placeholder="Enter your password" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <Button 
                        type="submit" 
                        className="w-full bg-primary hover:bg-primary/90"
                        disabled={loginMutation.isPending}
                      >
                        {loginMutation.isPending ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Logging in...
                          </>
                        ) : "Log In"}
                      </Button>
                    </form>
                  </Form>
                  
                  <p className="text-center text-gray-500 text-sm mt-4">
                    Don't have an account? <Button variant="link" onClick={() => setActiveTab("register")} className="p-0">Register</Button>
                  </p>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="register">
              <Card>
                <CardContent className="pt-6">
                  <Form {...registerForm}>
                    <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
                      <FormField
                        control={registerForm.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Full Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter your full name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={registerForm.control}
                        name="username"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Username</FormLabel>
                            <FormControl>
                              <Input placeholder="Choose a username" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={registerForm.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Password</FormLabel>
                            <FormControl>
                              <Input type="password" placeholder="Create a password" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={registerForm.control}
                        name="confirmPassword"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Confirm Password</FormLabel>
                            <FormControl>
                              <Input type="password" placeholder="Confirm your password" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="space-y-4">
                        <h3 className="text-sm font-medium">Choose Vehicle Type</h3>
                        <div className="grid grid-cols-2 gap-4">
                          <div 
                            className={`border-2 rounded-lg p-4 cursor-pointer flex flex-col items-center transition duration-200 ${
                              selectedVehicleType === 'ev' 
                                ? 'border-secondary bg-secondary/5' 
                                : 'border-gray-200 hover:bg-gray-50'
                            }`}
                            onClick={() => {
                              setSelectedVehicleType('ev');
                              registerForm.setValue('vehicleType', 'ev');
                              registerForm.setValue('vehicleModel', vehicleModelsData.ev[0]);
                            }}
                          >
                            <div className="h-12 w-12 bg-secondary/10 rounded-full flex items-center justify-center mb-2">
                              <i className="material-icons text-secondary">electric_car</i>
                            </div>
                            <span className="font-medium">Electric Vehicle</span>
                          </div>
                          <div 
                            className={`border-2 rounded-lg p-4 cursor-pointer flex flex-col items-center transition duration-200 ${
                              selectedVehicleType === 'robot' 
                                ? 'border-secondary bg-secondary/5' 
                                : 'border-gray-200 hover:bg-gray-50'
                            }`}
                            onClick={() => {
                              setSelectedVehicleType('robot');
                              registerForm.setValue('vehicleType', 'robot');
                              registerForm.setValue('vehicleModel', vehicleModelsData.robot[0]);
                            }}
                          >
                            <div className="h-12 w-12 bg-secondary/10 rounded-full flex items-center justify-center mb-2">
                              <i className="material-icons text-secondary">precision_manufacturing</i>
                            </div>
                            <span className="font-medium">Delivery Robot</span>
                          </div>
                        </div>
                      </div>
                      
                      <FormField
                        control={registerForm.control}
                        name="vehicleModel"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Vehicle Model</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select a vehicle model" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {selectedVehicleType === 'ev' ? (
                                  vehicleModelsData.ev.map((model) => (
                                    <SelectItem key={model} value={model}>{model}</SelectItem>
                                  ))
                                ) : (
                                  vehicleModelsData.robot.map((model) => (
                                    <SelectItem key={model} value={model}>{model}</SelectItem>
                                  ))
                                )}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <Button 
                        type="submit" 
                        className="w-full bg-primary hover:bg-primary/90"
                        disabled={registerMutation.isPending}
                      >
                        {registerMutation.isPending ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Creating account...
                          </>
                        ) : "Create Account"}
                      </Button>
                    </form>
                  </Form>
                  
                  <p className="text-center text-gray-500 text-sm mt-4">
                    Already have an account? <Button variant="link" onClick={() => setActiveTab("login")} className="p-0">Log In</Button>
                  </p>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
      
      {/* Right side - Hero Section */}
      <div className="hidden sm:flex flex-col w-1/2 bg-gradient-to-br from-primary/90 to-secondary/90 p-12 text-white justify-center">
        <h2 className="text-4xl font-bold mb-6">Drive smarter, not harder</h2>
        <ul className="space-y-4">
          <li className="flex items-start">
            <i className="material-icons mr-3">dashboard</i>
            <span>Monitor your vehicle's performance in real-time</span>
          </li>
          <li className="flex items-start">
            <i className="material-icons mr-3">map</i>
            <span>Plan energy-efficient routes to reduce costs and emissions</span>
          </li>
          <li className="flex items-start">
            <i className="material-icons mr-3">security</i>
            <span>Enhance safety with AR overlays and hazard detection</span>
          </li>
          <li className="flex items-start">
            <i className="material-icons mr-3">eco</i>
            <span>Track your impact with detailed sustainability insights</span>
          </li>
          <li className="flex items-start">
            <i className="material-icons mr-3">engineering</i>
            <span>Predict maintenance needs before they become problems</span>
          </li>
        </ul>
      </div>
    </div>
  );
}
