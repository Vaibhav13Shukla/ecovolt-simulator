import { Switch, Route, Router } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { ThemeProvider } from "@/components/theme-provider";
import { queryClient } from "@/lib/queryClient";
import { AuthProvider } from "@/hooks/use-auth";

// Import your pages
import HomePage from "@/pages/home-page";
import DashboardPage from "@/pages/dashboard-page";
import AuthPage from "@/pages/auth-page";
import RoutePlannerPage from "@/pages/route-planner-page";
import AnalyticsPage from "@/pages/analytics-page";
import SafetyPage from "@/pages/safety-page";
import NotFound from "@/pages/not-found";
import { ProtectedRoute } from "@/lib/protected-route";

// For GitHub Pages deployment, we need to use a base path
// This is the repository name for GitHub Pages
const isProduction = process.env.NODE_ENV === "production";
const base = isProduction ? "/ecovolt-simulator" : "";

function RouterWithBasePath() {
  return (
    <Router base={base}>
      <Switch>
        <Route path="/auth" component={AuthPage} />
        <ProtectedRoute path="/" component={HomePage} />
        <ProtectedRoute path="/dashboard" component={DashboardPage} />
        <ProtectedRoute path="/route-planner" component={RoutePlannerPage} />
        <ProtectedRoute path="/analytics" component={AnalyticsPage} />
        <ProtectedRoute path="/safety" component={SafetyPage} />
        <Route component={NotFound} />
      </Switch>
    </Router>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="light" storageKey="ecovolt-theme">
        <AuthProvider>
          <RouterWithBasePath />
          <Toaster />
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}