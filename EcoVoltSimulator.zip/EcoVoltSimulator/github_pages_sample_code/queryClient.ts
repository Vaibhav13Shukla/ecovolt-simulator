import { QueryClient } from "@tanstack/react-query";
import { mockUser, mockVehicle, mockMetrics, mockBadges, mockStats, mockFetch } from "@/lib/mockData";

// Check if we're in GitHub Pages environment
const isStaticHosting = process.env.NODE_ENV === "production";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const message = await res.text();
    throw new Error(message || res.statusText);
  }
}

export async function apiRequest(
  method: "GET" | "POST" | "PUT" | "DELETE" | "PATCH",
  url: string,
  body?: any,
) {
  // If in static hosting mode (GitHub Pages), mock the API requests
  if (isStaticHosting) {
    console.log(`[Mock API] ${method} ${url}`);
    
    // Simulate backend responses based on the endpoint
    switch (url) {
      case "/api/login":
        if (body?.username === "demo" && body?.password === "password") {
          return { 
            ok: true, 
            json: async () => mockUser,
            status: 200,
            statusText: "OK"
          };
        }
        return { 
          ok: false, 
          text: async () => "Invalid credentials",
          status: 401,
          statusText: "Unauthorized"
        };
      
      case "/api/register":
        return { 
          ok: true, 
          json: async () => mockUser,
          status: 201,
          statusText: "Created"
        };
        
      case "/api/logout":
        return { 
          ok: true, 
          status: 200,
          statusText: "OK"
        };
        
      case "/api/user":
        return { 
          ok: true, 
          json: async () => mockUser,
          status: 200,
          statusText: "OK"
        };
        
      case "/api/vehicle":
        return { 
          ok: true, 
          json: async () => mockVehicle,
          status: 200,
          statusText: "OK"
        };
        
      case "/api/metrics/latest":
        return { 
          ok: true, 
          json: async () => mockMetrics,
          status: 200,
          statusText: "OK"
        };
        
      case "/api/badges":
        return { 
          ok: true, 
          json: async () => mockBadges,
          status: 200,
          statusText: "OK"
        };
        
      case "/api/stats":
        return { 
          ok: true, 
          json: async () => mockStats,
          status: 200,
          statusText: "OK"
        };
        
      default:
        return { 
          ok: false, 
          text: async () => "Not found",
          status: 404,
          statusText: "Not Found"
        };
    }
  }
  
  // Normal API request for development environment
  const options: RequestInit = { method };
  
  if (body) {
    options.body = JSON.stringify(body);
    options.headers = {
      "Content-Type": "application/json",
    };
  }
  
  const res = await fetch(url, options);
  await throwIfResNotOk(res);
  return res;
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn = <T>(options: {
  on401: UnauthorizedBehavior;
}) => {
  return async ({ queryKey }: { queryKey: string[] }): Promise<T | undefined> => {
    // For static hosting (GitHub Pages), return mock data
    if (isStaticHosting) {
      const endpoint = queryKey[0];
      switch (endpoint) {
        case "/api/user":
          return mockUser as unknown as T;
        case "/api/vehicle":
          return mockVehicle as unknown as T;
        case "/api/metrics/latest":
          return mockMetrics as unknown as T;
        case "/api/badges":
          return mockBadges as unknown as T;
        case "/api/stats":
          return mockStats as unknown as T;
        default:
          return undefined;
      }
    }

    // Normal query function for development environment
    const queryString = queryKey.join("/");
    const res = await fetch(queryString);
    
    if (res.status === 401) {
      if (options.on401 === "returnNull") {
        return undefined;
      } else {
        const text = await res.text();
        throw new Error(text || "Unauthorized");
      }
    }
    
    await throwIfResNotOk(res);
    const data = await res.json();
    return data;
  };
};

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: false,
    },
  },
});