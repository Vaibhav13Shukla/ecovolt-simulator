import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";
import { Redirect, Route } from "wouter";

// Check if we're in GitHub Pages environment
const isStaticHosting = process.env.NODE_ENV === "production";
// For GitHub Pages, we need a base path
const base = isStaticHosting ? "/ecovolt-simulator" : "";

export function ProtectedRoute({
  path,
  component: Component,
}: {
  path: string;
  component: () => React.JSX.Element;
}) {
  const { user, isLoading } = useAuth();

  // For GitHub Pages static hosting, we always allow access
  // and just use mock data
  if (isStaticHosting) {
    return <Route path={path} component={Component} />;
  }

  if (isLoading) {
    return (
      <Route path={path}>
        <div className="flex items-center justify-center min-h-screen">
          <Loader2 className="h-8 w-8 animate-spin text-border" />
        </div>
      </Route>
    );
  }

  if (!user) {
    return (
      <Route path={path}>
        <Redirect to={`${base}/auth`} />
      </Route>
    );
  }

  return <Route path={path} component={Component} />;
}