# How to Download Your Code from Replit

## Method 1: Using Replit's UI

1. In the Replit editor:
   - Click on the three dots (...) in the Files panel
   - Select "Download as ZIP"
   - Save the ZIP file to your computer
   - Extract the ZIP file to a folder on your computer

## Method 2: Using Git

If you prefer to use Git to download your code (which can be better for preserving file permissions):

1. First, ensure Git is installed on your computer
2. Open a terminal or command prompt on your computer
3. Run the following commands:

```bash
# Clone the repository
git clone https://github.com/replit/replit-code-rev-2.git ecovolt-simulator

# Navigate to the project directory
cd ecovolt-simulator

# Download any dependencies
npm install
```

## After Downloading

1. Navigate to the downloaded and extracted project folder
2. Follow the instructions in the `GITHUB_DEPLOY_INSTRUCTIONS.md` file to deploy your project to GitHub Pages

## Important Files to Copy

Make sure these files are included in your download:

- All the folders: `client`, `server`, `shared`, `.github`, etc.
- README.md
- LICENSE
- GITHUB_DEPLOY_INSTRUCTIONS.md
- All the configuration files (.gitignore, etc.)

## Making Changes to the Project

After downloading, you might want to make the following changes:

1. Update the `package.json` file as described in the deployment instructions
2. Modify the Vite configuration as needed
3. Create a screenshot of the application for your README
4. Update any paths or URLs to match your GitHub username and repository name

## Testing Locally Before Deployment

To make sure everything works before deploying:

1. Open a terminal in the project directory
2. Install dependencies if you haven't already:
   ```bash
   npm install
   ```
3. Start the development server:
   ```bash
   npm run dev
   ```
4. Open your browser to `http://localhost:5000`
5. Verify that the application works as expected

## Next Steps

After downloading and testing your code, follow the instructions in the `GITHUB_DEPLOY_INSTRUCTIONS.md` file to deploy your EcoVolt Simulator to GitHub Pages.