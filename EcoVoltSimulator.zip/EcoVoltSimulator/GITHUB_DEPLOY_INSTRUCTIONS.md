# Complete Guide to Deploying EcoVolt Simulator on GitHub Pages

This guide provides detailed steps to deploy your EcoVolt Simulator application to GitHub Pages for free.

## Step 1: Download Your Code from Replit

1. From the Replit interface:
   - Click on the 3 dots (...) in the files sidebar
   - Choose "Download as zip"
   - Save and extract the ZIP to a folder on your computer

## Step 2: Modify Your Project for GitHub Pages

1. **Update the package.json file**:
   ```json
   {
     "name": "ecovolt-simulator",
     "version": "1.0.0",
     "type": "module",
     "license": "MIT",
     "homepage": "https://yourusername.github.io/ecovolt-simulator",
     "scripts": {
       "dev": "NODE_ENV=development tsx server/index.ts",
       "build": "vite build",
       "start": "NODE_ENV=production node dist/index.js",
       "check": "tsc",
       "predeploy": "npm run build",
       "deploy": "gh-pages -d dist/client"
     },
     // The rest of your package.json remains the same
   }
   ```

2. **Create a vite.config.js file in your project root**:
   ```javascript
   import { defineConfig } from "vite";
   import react from "@vitejs/plugin-react";
   import path from "path";

   // Replace with your actual GitHub repository name
   const repoName = "ecovolt-simulator";
   const isProduction = process.env.NODE_ENV === "production";

   export default defineConfig({
     plugins: [react()],
     base: isProduction ? `/${repoName}/` : "/",
     resolve: {
       alias: {
         "@": path.resolve(__dirname, "client", "src"),
         "@shared": path.resolve(__dirname, "shared"),
         "@assets": path.resolve(__dirname, "attached_assets"),
       },
     },
     root: path.resolve(__dirname, "client"),
     build: {
       outDir: path.resolve(__dirname, "dist/client"),
       emptyOutDir: true,
     },
   });
   ```

3. **Install the gh-pages package**:
   ```bash
   npm install gh-pages --save-dev
   ```

4. **Modify the Router in App.tsx** to work with GitHub Pages:
   ```typescript
   import { Switch, Route, useLocation, Router } from "wouter";

   // For GitHub Pages
   const base = process.env.NODE_ENV === "production" ? "/ecovolt-simulator" : "";
   const useBasename = (path: string) => `${base}${path}`;

   function App() {
     return (
       <Router base={base}>
         {/* Your routes... */}
       </Router>
     );
   }
   ```

## Step 3: Create a GitHub Repository

1. Go to [GitHub](https://github.com/) and log in
2. Click the "+" in the top right corner and select "New repository"
3. Name your repository "ecovolt-simulator"
4. Make it public
5. Click "Create repository" (don't add README or .gitignore)

## Step 4: Initialize Git and Push to GitHub

Open a terminal in your project directory and run:

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/yourusername/ecovolt-simulator.git
git push -u origin main
```

## Step 5: Deploy to GitHub Pages

In your project directory, run:

```bash
npm run deploy
```

This will:
1. Build your project (from the `predeploy` script)
2. Deploy it to the `gh-pages` branch on GitHub

## Step 6: Configure GitHub Pages Settings

1. Go to your repository on GitHub
2. Click "Settings"
3. Navigate to "Pages" in the sidebar
4. Under "Build and deployment" > "Source", select "Deploy from a branch"
5. In the "Branch" dropdown, select "gh-pages", then "/(root)" and click "Save"

## Step 7: Access Your Deployed Application

Your app will be available at:
```
https://yourusername.github.io/ecovolt-simulator/
```

It might take a few minutes for GitHub Pages to deploy your site.

## Notes on Backend Functionality

Since GitHub Pages only hosts static files:

1. **Auth functionality** won't work as there's no server to handle authentication
2. **API endpoints** won't function

You have three options:

1. **Make the app read-only**: Remove auth requirements and pre-populate with demo data
2. **Use a separate backend service**: Deploy the Express backend to Render, Railway, or other services
3. **Use serverless functions**: Convert your backend to use Netlify Functions, Vercel Edge Functions, or similar

For a simple demo, option #1 is recommended - you can modify the app to work without authentication and load pre-populated data for demo purposes.

## Making the App Work Without a Backend

1. **Create mock data in your frontend**:
   ```typescript
   // In a new file: client/src/lib/mockData.ts
   export const mockUser = {
     id: 1,
     username: "demo",
     name: "Demo User",
     vehicleType: "ev",
     vehicleModel: "Model X"
   };

   export const mockVehicle = {
     id: 1,
     userId: 1,
     type: "ev",
     model: "Model X",
     batteryLevel: 80,
     batteryHealth: 95,
     motorHealth: 92,
     range: 300,
     lastMaintenanceAt: new Date()
   };

   // Add more mock data as needed
   ```

2. **Modify your hooks to use mock data**:
   ```typescript
   // For example, in useAuth.tsx
   export function AuthProvider({ children }: { children: ReactNode }) {
     // Use mock data in production (GitHub Pages)
     const isProduction = process.env.NODE_ENV === "production";
     
     const {
       data: user,
       error,
       isLoading,
     } = useQuery<SelectUser>({
       queryKey: ["/api/user"],
       queryFn: isProduction 
         ? () => Promise.resolve(mockUser) 
         : getQueryFn({ on401: "returnNull" }),
     });

     // Similar changes for other queries and mutations
   }
   ```

This approach will let visitors see the UI and interact with the app even though there's no backend server.