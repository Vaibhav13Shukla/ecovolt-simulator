import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { z } from "zod";
import { insertTripSchema, insertMetricsSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Sets up /api/register, /api/login, /api/logout, /api/user
  setupAuth(app);

  // Vehicle routes
  app.get("/api/vehicle", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = req.user!.id;
    
    try {
      const vehicle = await storage.getVehicleByUserId(userId);
      if (!vehicle) {
        return res.status(404).json({ message: "Vehicle not found" });
      }
      
      res.json(vehicle);
    } catch (error) {
      res.status(500).json({ message: "Error fetching vehicle data" });
    }
  });

  app.patch("/api/vehicle/battery", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = req.user!.id;
    
    const schema = z.object({
      level: z.number().min(0).max(100)
    });
    
    try {
      const { level } = schema.parse(req.body);
      const updatedVehicle = await storage.updateVehicleBatteryLevel(userId, level);
      
      if (!updatedVehicle) {
        return res.status(404).json({ message: "Vehicle not found" });
      }
      
      res.json(updatedVehicle);
    } catch (error) {
      res.status(400).json({ message: "Invalid request data" });
    }
  });

  // Metrics routes
  app.get("/api/metrics/latest", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = req.user!.id;
    
    try {
      const metrics = await storage.getLatestMetricsByUserId(userId);
      if (!metrics) {
        return res.status(404).json({ message: "No metrics found" });
      }
      
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ message: "Error fetching metrics data" });
    }
  });

  app.get("/api/metrics/history", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = req.user!.id;
    
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 7;
    
    try {
      const metrics = await storage.getMetricsHistoryByUserId(userId, limit);
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ message: "Error fetching metrics history" });
    }
  });

  app.post("/api/metrics", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = req.user!.id;
    
    try {
      const metricsData = insertMetricsSchema.parse({
        ...req.body,
        userId
      });
      
      const newMetrics = await storage.createMetrics(metricsData);
      res.status(201).json(newMetrics);
    } catch (error) {
      res.status(400).json({ message: "Invalid metrics data" });
    }
  });

  // Trip routes
  app.get("/api/trips", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = req.user!.id;
    
    try {
      const trips = await storage.getTripsByUserId(userId);
      res.json(trips);
    } catch (error) {
      res.status(500).json({ message: "Error fetching trips" });
    }
  });

  app.post("/api/trips", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = req.user!.id;
    
    try {
      const tripData = insertTripSchema.parse({
        ...req.body,
        userId
      });
      
      const newTrip = await storage.createTrip(tripData);
      
      // If this is an eco trip, update the Route Genius badge
      if (tripData.routeType === "eco") {
        const badges = await storage.getBadgesByUserId(userId);
        const routeGeniusBadge = badges.find(badge => badge.name === "Route Genius");
        
        if (routeGeniusBadge) {
          await storage.updateBadgeProgress(routeGeniusBadge.id, routeGeniusBadge.progress + 1);
        }
      }
      
      // Update Eco Master badge with CO2 saved
      const badges = await storage.getBadgesByUserId(userId);
      const ecoMasterBadge = badges.find(badge => badge.name === "Eco Master");
      
      if (ecoMasterBadge) {
        const newProgress = ecoMasterBadge.progress + Number(tripData.co2Saved);
        await storage.updateBadgeProgress(ecoMasterBadge.id, newProgress);
      }
      
      // Update Energy Saver badge
      const energySaverBadge = badges.find(badge => badge.name === "Energy Saver");
      if (energySaverBadge && tripData.routeType === "eco") {
        // Assume energy savings of 1.2 kWh per eco trip (as per requirements)
        const newProgress = energySaverBadge.progress + 1.2;
        await storage.updateBadgeProgress(energySaverBadge.id, newProgress);
      }
      
      res.status(201).json(newTrip);
    } catch (error) {
      res.status(400).json({ message: "Invalid trip data" });
    }
  });

  // Stats routes
  app.get("/api/stats", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = req.user!.id;
    
    try {
      const totalTrips = await storage.getTripsCountByUserId(userId);
      const ecoTrips = await storage.getEcoTripsCountByUserId(userId);
      const badges = await storage.getBadgesByUserId(userId);
      const vehicle = await storage.getVehicleByUserId(userId);
      const latestMetrics = await storage.getLatestMetricsByUserId(userId);
      
      res.json({
        totalTrips,
        ecoTrips,
        badges,
        vehicle,
        metrics: latestMetrics
      });
    } catch (error) {
      res.status(500).json({ message: "Error fetching stats" });
    }
  });

  // Badge routes
  app.get("/api/badges", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = req.user!.id;
    
    try {
      const badges = await storage.getBadgesByUserId(userId);
      res.json(badges);
    } catch (error) {
      res.status(500).json({ message: "Error fetching badges" });
    }
  });

  // Simulation routes - generate mock data for simulation
  app.post("/api/simulate/route", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = req.user!.id;
    
    const schema = z.object({
      startPoint: z.string(),
      endPoint: z.string(),
      routeType: z.enum(["eco", "standard"])
    });
    
    try {
      const { startPoint, endPoint, routeType } = schema.parse(req.body);
      
      // Get the latest metrics to update from there
      const latestMetrics = await storage.getLatestMetricsByUserId(userId);
      if (!latestMetrics) {
        return res.status(404).json({ message: "No metrics found" });
      }
      
      // Simulate distance based on route type (eco routes are typically longer)
      const baseDist = Math.random() * 10 + 5; // 5-15 km
      const distance = routeType === "eco" ? baseDist * 1.15 : baseDist;
      
      // Simulate energy usage based on route type (eco routes use less energy)
      const baseEnergyUsed = distance * 0.2; // 0.2 kWh per km
      const energyUsed = routeType === "eco" ? baseEnergyUsed * 0.85 : baseEnergyUsed;
      
      // Calculate CO2 savings (for eco routes only)
      const co2Saved = routeType === "eco" ? energyUsed * 0.5 : 0; // 0.5 kg CO2 per kWh
      
      // Update battery level based on energy used
      const batteryLevelDrop = energyUsed / 75 * 100; // Assuming 75kWh battery
      const newBatteryLevel = Math.max(0, latestMetrics.batteryLevel - batteryLevelDrop);
      
      // Create a new trip
      const trip = await storage.createTrip({
        userId,
        startPoint,
        endPoint,
        distance,
        energyUsed,
        co2Saved,
        routeType
      });
      
      // Update vehicle battery level
      const vehicle = await storage.getVehicleByUserId(userId);
      if (vehicle) {
        await storage.updateVehicleBatteryLevel(userId, Math.round(newBatteryLevel));
      }
      
      // Update metrics
      const totalCO2Saved = latestMetrics.co2Saved + co2Saved;
      const totalEnergySaved = latestMetrics.energySaved + (routeType === "eco" ? energyUsed * 0.15 : 0);
      
      // Calculate new eco score
      let ecoScore = latestMetrics.ecoScore;
      if (routeType === "eco") {
        ecoScore = Math.min(100, ecoScore + 2);
      } else {
        ecoScore = Math.max(0, ecoScore - 1);
      }
      
      const newMetrics = await storage.createMetrics({
        userId,
        batteryLevel: Math.round(newBatteryLevel),
        speed: 0, // After trip is complete
        distance: latestMetrics.distance + distance,
        batteryHealth: vehicle ? vehicle.batteryHealth : 100,
        motorHealth: vehicle ? vehicle.motorHealth : 100,
        ecoScore,
        co2Saved: totalCO2Saved,
        energySaved: totalEnergySaved
      });
      
      res.json({
        trip,
        metrics: newMetrics
      });
    } catch (error) {
      res.status(400).json({ message: "Invalid simulation data" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
