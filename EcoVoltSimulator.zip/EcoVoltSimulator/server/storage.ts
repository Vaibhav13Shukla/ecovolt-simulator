import { users, trips, badges, vehicles, metrics, type User, type InsertUser, type Trip, type InsertTrip, type Badge, type InsertBadge, type Vehicle, type InsertVehicle, type Metrics, type InsertMetrics } from "@shared/schema";
import createMemoryStore from "memorystore";
import session from "express-session";

// Create memory store for sessions
const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User related operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserEcoLevel(userId: number, ecoLevel: string): Promise<User | undefined>;
  
  // Trip related operations
  createTrip(trip: InsertTrip): Promise<Trip>;
  getTripsByUserId(userId: number): Promise<Trip[]>;
  getTripsCountByUserId(userId: number): Promise<number>;
  getEcoTripsCountByUserId(userId: number): Promise<number>;
  
  // Badge related operations
  createBadge(badge: InsertBadge): Promise<Badge>;
  getBadgesByUserId(userId: number): Promise<Badge[]>;
  updateBadgeProgress(badgeId: number, progress: number): Promise<Badge | undefined>;
  
  // Vehicle related operations
  getVehicleByUserId(userId: number): Promise<Vehicle | undefined>;
  createVehicle(vehicle: InsertVehicle): Promise<Vehicle>;
  updateVehicleBatteryLevel(userId: number, level: number): Promise<Vehicle | undefined>;
  
  // Metrics related operations
  createMetrics(metrics: InsertMetrics): Promise<Metrics>;
  getLatestMetricsByUserId(userId: number): Promise<Metrics | undefined>;
  getMetricsHistoryByUserId(userId: number, limit: number): Promise<Metrics[]>;

  // Session store
  sessionStore: session.SessionStore;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private trips: Map<number, Trip>;
  private badges: Map<number, Badge>;
  private vehicles: Map<number, Vehicle>;
  private metrics: Map<number, Metrics>;
  sessionStore: session.SessionStore;
  
  private userIdCounter: number;
  private tripIdCounter: number;
  private badgeIdCounter: number;
  private vehicleIdCounter: number;
  private metricsIdCounter: number;

  constructor() {
    this.users = new Map();
    this.trips = new Map();
    this.badges = new Map();
    this.vehicles = new Map();
    this.metrics = new Map();
    
    this.userIdCounter = 1;
    this.tripIdCounter = 1;
    this.badgeIdCounter = 1;
    this.vehicleIdCounter = 1;
    this.metricsIdCounter = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
    });
    
    // Create demo user for testing
    this.createDemoUser();
  }
  
  // Create a default demo user
  private async createDemoUser() {
    // Use simple password for demo
    const salt = "abcdef1234567890";
    const hashedPassword = "5f4dcc3b5aa765d61d8327deb882cf99." + salt; // md5 of "password" + salt
    
    const demoUser: User = {
      id: 1,
      username: 'demo',
      password: hashedPassword,
      name: 'Demo User',
      vehicleType: 'ev',
      vehicleModel: 'Model X',
      ecoLevel: 'Eco-Novice',
      createdAt: new Date()
    };
    this.users.set(demoUser.id, demoUser);
    console.log('Demo user created:', demoUser.username);
    
    // Create vehicle for demo user
    const vehicle: Vehicle = {
      id: this.vehicleIdCounter++,
      userId: demoUser.id,
      type: demoUser.vehicleType,
      model: demoUser.vehicleModel,
      batteryLevel: 80,
      batteryHealth: 95,
      motorHealth: 92,
      range: 250,
      createdAt: new Date()
    };
    this.vehicles.set(vehicle.id, vehicle);
    
    // Create metrics for demo user
    const metricsData: Metrics = {
      id: this.metricsIdCounter++,
      userId: demoUser.id,
      batteryLevel: 80,
      speed: 0,
      distance: "120",
      batteryHealth: 95,
      motorHealth: 92,
      ecoScore: 75,
      co2Saved: "8.5",
      energySaved: "14.2",
      createdAt: new Date()
    };
    this.metrics.set(metricsData.id, metricsData);
    
    // Create badges for demo user
    const badges = [
      {
        name: "Eco Master",
        description: "Save 10kg of CO2",
        icon: "eco",
        progress: 85,
        target: 100,
        achieved: false
      },
      {
        name: "Energy Saver",
        description: "Save 20kWh of energy",
        icon: "bolt",
        progress: 70,
        target: 100,
        achieved: false
      },
      {
        name: "Route Genius",
        description: "Complete 5 eco-friendly trips",
        icon: "map",
        progress: 60,
        target: 100,
        achieved: false
      }
    ];
    
    for (const badgeData of badges) {
      const badge: Badge = {
        id: this.badgeIdCounter++,
        userId: demoUser.id,
        name: badgeData.name,
        description: badgeData.description,
        icon: badgeData.icon,
        progress: badgeData.progress,
        target: badgeData.target,
        achieved: badgeData.achieved,
        achievedAt: undefined,
        createdAt: new Date()
      };
      this.badges.set(badge.id, badge);
    }
  }

  // User related operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id, 
      ecoLevel: "Eco-Novice",
      createdAt: now
    };
    this.users.set(id, user);
    return user;
  }

  async updateUserEcoLevel(userId: number, ecoLevel: string): Promise<User | undefined> {
    const user = await this.getUser(userId);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ecoLevel };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  // Trip related operations
  async createTrip(insertTrip: InsertTrip): Promise<Trip> {
    const id = this.tripIdCounter++;
    const now = new Date();
    const trip: Trip = {
      ...insertTrip,
      id,
      createdAt: now
    };
    this.trips.set(id, trip);
    return trip;
  }

  async getTripsByUserId(userId: number): Promise<Trip[]> {
    return Array.from(this.trips.values()).filter(
      (trip) => trip.userId === userId
    );
  }

  async getTripsCountByUserId(userId: number): Promise<number> {
    return (await this.getTripsByUserId(userId)).length;
  }

  async getEcoTripsCountByUserId(userId: number): Promise<number> {
    const trips = await this.getTripsByUserId(userId);
    return trips.filter(trip => trip.routeType === "eco").length;
  }

  // Badge related operations
  async createBadge(insertBadge: InsertBadge): Promise<Badge> {
    const id = this.badgeIdCounter++;
    const badge: Badge = {
      ...insertBadge,
      id
    };
    this.badges.set(id, badge);
    return badge;
  }

  async getBadgesByUserId(userId: number): Promise<Badge[]> {
    return Array.from(this.badges.values()).filter(
      (badge) => badge.userId === userId
    );
  }

  async updateBadgeProgress(badgeId: number, progress: number): Promise<Badge | undefined> {
    const badge = this.badges.get(badgeId);
    if (!badge) return undefined;
    
    const achieved = progress >= badge.target;
    const achievedAt = achieved && !badge.achieved ? new Date() : badge.achievedAt;
    
    const updatedBadge: Badge = {
      ...badge,
      progress,
      achieved,
      achievedAt
    };
    
    this.badges.set(badgeId, updatedBadge);
    return updatedBadge;
  }

  // Vehicle related operations
  async getVehicleByUserId(userId: number): Promise<Vehicle | undefined> {
    return Array.from(this.vehicles.values()).find(
      (vehicle) => vehicle.userId === userId
    );
  }

  async createVehicle(insertVehicle: InsertVehicle): Promise<Vehicle> {
    const id = this.vehicleIdCounter++;
    const now = new Date();
    const vehicle: Vehicle = {
      ...insertVehicle,
      id,
      lastMaintenanceAt: now
    };
    this.vehicles.set(id, vehicle);
    return vehicle;
  }

  async updateVehicleBatteryLevel(userId: number, level: number): Promise<Vehicle | undefined> {
    const vehicle = await this.getVehicleByUserId(userId);
    if (!vehicle) return undefined;
    
    const updatedVehicle: Vehicle = {
      ...vehicle,
      batteryLevel: level
    };
    
    this.vehicles.set(vehicle.id, updatedVehicle);
    return updatedVehicle;
  }

  // Metrics related operations
  async createMetrics(insertMetrics: InsertMetrics): Promise<Metrics> {
    const id = this.metricsIdCounter++;
    const now = new Date();
    const metricsData: Metrics = {
      ...insertMetrics,
      id,
      timestamp: now
    };
    this.metrics.set(id, metricsData);
    return metricsData;
  }

  async getLatestMetricsByUserId(userId: number): Promise<Metrics | undefined> {
    const userMetrics = Array.from(this.metrics.values())
      .filter(metric => metric.userId === userId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
    
    return userMetrics.length > 0 ? userMetrics[0] : undefined;
  }

  async getMetricsHistoryByUserId(userId: number, limit: number): Promise<Metrics[]> {
    return Array.from(this.metrics.values())
      .filter(metric => metric.userId === userId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }
}

export const storage = new MemStorage();
