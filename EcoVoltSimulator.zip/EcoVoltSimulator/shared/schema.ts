import { pgTable, text, serial, integer, decimal, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User Schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  vehicleType: text("vehicle_type").notNull(),
  vehicleModel: text("vehicle_model").notNull(),
  ecoLevel: text("eco_level").default("Eco-Novice").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  name: true,
  vehicleType: true,
  vehicleModel: true,
});

// Trip Schema
export const trips = pgTable("trips", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  startPoint: text("start_point").notNull(),
  endPoint: text("end_point").notNull(),
  distance: decimal("distance").notNull(),
  energyUsed: decimal("energy_used").notNull(),
  co2Saved: decimal("co2_saved").notNull(),
  routeType: text("route_type").notNull(), // "eco" or "standard"
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertTripSchema = createInsertSchema(trips).pick({
  userId: true,
  startPoint: true,
  endPoint: true,
  distance: true,
  energyUsed: true,
  co2Saved: true,
  routeType: true,
});

// Badge Schema
export const badges = pgTable("badges", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  icon: text("icon").notNull(),
  progress: integer("progress").notNull(),
  target: integer("target").notNull(),
  achieved: boolean("achieved").default(false).notNull(),
  achievedAt: timestamp("achieved_at"),
});

export const insertBadgeSchema = createInsertSchema(badges).pick({
  userId: true,
  name: true,
  description: true,
  icon: true,
  progress: true,
  target: true,
  achieved: true,
  achievedAt: true,
});

// Vehicle Schema
export const vehicles = pgTable("vehicles", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().unique(),
  type: text("type").notNull(),
  model: text("model").notNull(),
  batteryLevel: integer("battery_level").default(100).notNull(),
  batteryHealth: integer("battery_health").default(100).notNull(),
  motorHealth: integer("motor_health").default(100).notNull(),
  range: integer("range").default(300).notNull(),
  lastMaintenanceAt: timestamp("last_maintenance_at").defaultNow().notNull(),
});

export const insertVehicleSchema = createInsertSchema(vehicles).pick({
  userId: true,
  type: true,
  model: true,
  batteryLevel: true,
  batteryHealth: true,
  motorHealth: true,
  range: true,
});

// Simulated vehicle metrics for the dashboard
export const metrics = pgTable("metrics", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  batteryLevel: integer("battery_level").notNull(),
  speed: integer("speed").notNull(),
  distance: decimal("distance").notNull(),
  batteryHealth: integer("battery_health").notNull(),
  motorHealth: integer("motor_health").notNull(),
  ecoScore: integer("eco_score").notNull(),
  co2Saved: decimal("co2_saved").notNull(),
  energySaved: decimal("energy_saved").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

export const insertMetricsSchema = createInsertSchema(metrics).pick({
  userId: true,
  batteryLevel: true,
  speed: true,
  distance: true,
  batteryHealth: true,
  motorHealth: true,
  ecoScore: true,
  co2Saved: true,
  energySaved: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertTrip = z.infer<typeof insertTripSchema>;
export type Trip = typeof trips.$inferSelect;

export type InsertBadge = z.infer<typeof insertBadgeSchema>;
export type Badge = typeof badges.$inferSelect;

export type InsertVehicle = z.infer<typeof insertVehicleSchema>;
export type Vehicle = typeof vehicles.$inferSelect;

export type InsertMetrics = z.infer<typeof insertMetricsSchema>;
export type Metrics = typeof metrics.$inferSelect;

// Extended schemas
export const loginSchema = insertUserSchema.pick({
  username: true,
  password: true,
});

export type LoginData = z.infer<typeof loginSchema>;

// Vehicle models data
export const vehicleModelsData = {
  ev: [
    "Tesla Model 3",
    "Tesla Model Y",
    "Rivian R1T",
    "Nissan Leaf",
    "Chevy Bolt",
    "Ford Mustang Mach-E",
    "Hyundai Ioniq 5",
    "Kia EV6"
  ],
  robot: [
    "Starship Delivery",
    "Amazon Scout",
    "Kiwibot",
    "Postmates Serve",
    "Nuro R2",
    "AutoX Robotaxi",
    "TeleRetail Robot",
    "Robby Technologies"
  ]
};
