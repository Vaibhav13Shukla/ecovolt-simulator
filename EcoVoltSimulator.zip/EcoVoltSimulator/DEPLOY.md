# Deployment Guide for EcoVolt Simulator

This guide will help you deploy the EcoVolt Simulator application on GitHub Pages.

## Prerequisites

- A GitHub account
- Git installed on your local machine
- Node.js (version 18 or higher) installed on your local machine
- npm (comes with Node.js) or Yarn

## Step 1: Download the Code from Replit

1. In your Replit project, click on the three dots (...) in the files panel
2. Select "Download as ZIP"
3. Extract the ZIP file to a local folder on your computer

## Step 2: Update package.json

Open the `package.json` file in the extracted folder and add the following:

1. Change the name to your project name:
```json
"name": "ecovolt-simulator",
```

2. Add a homepage entry (replace `yourusername` with your GitHub username):
```json
"homepage": "https://yourusername.github.io/ecovolt-simulator",
```

3. Add GitHub Pages deployment scripts:
```json
"scripts": {
  "dev": "NODE_ENV=development tsx server/index.ts",
  "build": "vite build && esbuild server/index.ts --platform=node --packages=external --bundle --format=esm --outdir=dist",
  "start": "NODE_ENV=production node dist/index.js",
  "check": "tsc",
  "db:push": "drizzle-kit push",
  "predeploy": "npm run build",
  "deploy": "gh-pages -d dist/client"
}
```

## Step 3: Install GitHub Pages Package

```bash
npm install gh-pages --save-dev
```

## Step 4: Create a New GitHub Repository

1. Go to GitHub and create a new repository named `ecovolt-simulator`
2. Make the repository public
3. Don't initialize with README, .gitignore, or license (we already have these)

## Step 5: Initialize Git and Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/yourusername/ecovolt-simulator.git
git push -u origin main
```

## Step 6: Deploy to GitHub Pages Manually

For the first deployment, run:

```bash
npm run deploy
```

This will:
1. Build your project
2. Push the build files to the `gh-pages` branch of your repository

## Step 7: Configure GitHub Pages

1. Go to your repository on GitHub
2. Click on "Settings"
3. Go to "Pages" in the sidebar
4. Under "Source", select "Deploy from a branch"
5. Select the "gh-pages" branch and "/root" folder
6. Click "Save"

## Step 8: Access Your Deployed Application

Your application will be available at:
```
https://yourusername.github.io/ecovolt-simulator
```

Note that it might take a few minutes for your site to be deployed after pushing to GitHub.

## Automated Deployments

After the initial setup, any push to the main branch will trigger the GitHub Actions workflow defined in `.github/workflows/deploy.yml`, which will automatically build and deploy your project to GitHub Pages.

## Troubleshooting

- If your application shows a blank page, check the browser console for errors related to paths
- Make sure all your asset paths are relative
- If you're seeing 404 errors, make sure your router is configured for GitHub Pages (which uses a single HTML file)